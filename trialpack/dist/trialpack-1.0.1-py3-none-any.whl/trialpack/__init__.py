from .tp import display_custom_zen1, display_custom_zen2

display_custom_zen1()
display_custom_zen2()
