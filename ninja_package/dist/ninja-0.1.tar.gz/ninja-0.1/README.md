# Ninja Package

This package provides a custom ninja module for programming principles.

## Installation

You can install this package using pip:

```bash
pip install ninja
