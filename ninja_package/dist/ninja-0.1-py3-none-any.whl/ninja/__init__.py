# ninja/__init__.py

from .ninja import display_custom_ninja
